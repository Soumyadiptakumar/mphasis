import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Bookabed } from './bookabed';


@Injectable({
  providedIn: 'root'
})

  export class BookabedService {

    private basePath = 'http://localhost:8090/rest/bookabed';
  
    constructor(private http: HttpClient) { }
  
  
    getAllBookabeds(): Observable<Bookabed[]> {
      return this.http.get<Bookabed[]>(`${this.basePath}/all`);
    }
  
    deleteOneBookabed(id: number): Observable<any> {
      return this.http.delete(`${this.basePath}/remove/${id}`, {responseType: 'text'});
    }
  
    createBookabed(bookabed: Bookabed): Observable<any> {
      return this.http.post(`${this.basePath}/save`, bookabed, {responseType: 'text'});
    }
  
    getOneBookabed(id: number): Observable<Bookabed> {
      return this.http.get<Bookabed>(`${this.basePath}/one/${id}`);
    }
  
    updateBookabed(id: number, bookabed: Bookabed): Observable<any> {
      return this.http.put(`${this.basePath}/modify/${id}`, bookabed, {responseType : 'text'});
    }
  
  
}
