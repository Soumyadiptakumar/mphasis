import { Component, OnInit } from '@angular/core';
import { Covidtest } from '../covidtest';
import { CovidtestService } from '../covidtest.service';

@Component({
  selector: 'app-covidtest',
  templateUrl: './covidtest.component.html',
  styleUrls: ['./covidtest.component.css']
})
export class CovidtestComponent implements OnInit {
  covidtest: Covidtest;
  // message to ui
  message: string;

  // inject service class
  constructor(private service: CovidtestService) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.covidtest = new Covidtest();
  }

  // tslint:disable-next-line: typedef
  createCovidtest() {
    this.service.createCovidtest(this.covidtest)
    .subscribe(data => {
      this.message = data; // read message
      this.covidtest = new Covidtest(); // clear form
    }, error => {
      console.log(error);
    });


 }


}
