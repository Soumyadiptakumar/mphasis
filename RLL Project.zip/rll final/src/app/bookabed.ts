
export class Bookabed {
    id: number;
    name: string;
    email: string;
    address: string;
    contacts: string;
    tests: string;
    report: string;
    oxygen: string;
}