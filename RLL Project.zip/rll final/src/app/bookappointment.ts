
export class Bookappointment {
    id: number;
    dname: string;
    pname: string;
    contacts: string;
    email: string;
    report: string;
    vac: string;
    tslot: string;
}