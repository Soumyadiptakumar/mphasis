package com.javatpoint;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  

  
@Controller  
public class HelloWorldController {  
      
    @RequestMapping("/hello")  
    public ModelAndView helloWorld(HttpServletRequest request,HttpServletResponse res) throws IOException 
    {  
    	PrintWriter pw=res.getWriter();
    	res.setContentType("text/html");
    	String a =request.getParameter("t1");
    	String b =request.getParameter("t2");
    	String c =request.getParameter("t3");
    	String d =request.getParameter("t4");
    	if(d.equals("insert"))
    	{
    	try 
    	{ 
    		Class.forName("oracle.jdbc.driver.OracleDriver");
    		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
    		PreparedStatement st=con.prepareStatement("insert into  employee4 values(?,?,?)");
    		
    		st.setString(1,a);
    		st.setString(2,b);
    		st.setString(3,c);
    		st.execute();
    	 
         
        
    }catch(Exception e) 
    	{
    	e.printStackTrace();
    }
    	String message = "submitted "+a;  
        return new ModelAndView("hellopage", "message",message);  
    	}   
    	else if(d.equals("update"))
    	{
    	try 
    	{ 
    		Class.forName("oracle.jdbc.driver.OracleDriver");
    		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
    		PreparedStatement st=con.prepareStatement("update employee4 set t2=?, t3=? where t1=?");
    		
    		st.setString(1,b);
    		st.setString(2,c);
    		st.setString(3,a);
    		st.execute();
    	 
         
        
    }catch(Exception e) 
    	{
    	e.printStackTrace();
    }
    	String message = "updated "+a;  
        return new ModelAndView("hellopage", "message",message);  
    	} 
    	else
    	{
    	try 
    	{ 
    		Class.forName("oracle.jdbc.driver.OracleDriver");
    		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
    		PreparedStatement st=con.prepareStatement("delete from employee4 where t1=?");
    		
    		st.setString(1,a);
    	
    		st.execute();
    	 
         
        
    }catch(Exception e) 
    	{
    	e.printStackTrace();
    }
    	String message = "deleted "+a;  
        return new ModelAndView("hellopage", "message",message);  
    	}    
}
}