import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vaccination',
  templateUrl: './vaccination.component.html',
  styleUrls: ['./vaccination.component.css']
})
export class VaccinationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
