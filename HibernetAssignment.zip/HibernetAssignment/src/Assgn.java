import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.hibernate.*;
import org.hibernate.cfg.*;
import javax.servlet.annotation.*;
@WebServlet("/Assgn")
public class Assgn extends HttpServlet
{	public void service(HttpServletRequest req,HttpServletResponse res)
			throws ServletException,IOException
	{		try
		{	res.setContentType("text/html");
			PrintWriter pw=res.getWriter();
			String a=req.getParameter("t1");
			String b=req.getParameter("t2");
			String c=req.getParameter("t3");
			String d=req.getParameter("t4");
			Configuration cfg1=new Configuration();
			 cfg1.configure("hibernate.cfg.xml");
			@SuppressWarnings("deprecation")
			SessionFactory sf1=cfg1.configure().buildSessionFactory();
			Session ss1=sf1.openSession();
			mypojolol pojo=new mypojolol();
			pojo.setName1(a);
			pojo.setSalary(b);
			pojo.setAddress(c);
			pojo.setDessignation(d);
			Transaction tx=ss1.beginTransaction();
			ss1.save(pojo);
			tx.commit();
			ss1.close();
			res.sendRedirect("success1.html");
		}
		catch(Exception ae)
		{	ae.printStackTrace();	}	}}


