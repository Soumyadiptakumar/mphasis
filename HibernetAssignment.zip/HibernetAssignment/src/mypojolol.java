public class mypojolol
{
	String name1,salary,address,dessignation;

	public String getName1() {
		return name1;
	}

	public void setName1(String name1) {
		this.name1 = name1;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDessignation() {
		return dessignation;
	}

	public void setDessignation(String dessignation) {
		this.dessignation = dessignation;
	}

	
	
}